<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="decoration" tilewidth="64" tileheight="64" tilecount="171" columns="19">
 <image source="C:/Users/PC/Desktop/level2_decor.png" width="1216" height="576"/>
</tileset>
